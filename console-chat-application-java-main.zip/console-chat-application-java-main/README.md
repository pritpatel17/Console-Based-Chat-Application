# console-chat-application-java
It is console based chat application two persons can do chat on same network by establishing connection between them. Concepts of Socket programming and Multithreading is used
